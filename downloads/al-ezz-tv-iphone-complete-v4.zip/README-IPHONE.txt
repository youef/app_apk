Al Ezz TV - iPhone & iPad Red Glass Cinema V4
Use immediately: https://app-apk-oquy.onrender.com/web/ (Safari > Share > Add to Home Screen)
ZIP includes full iOS source, XcodeGen project definition, artwork, current PWA viewer, and iPhone Simulator app.
Simulator .app cannot be installed on a real iPhone. Physical iPhone IPA requires Apple signing.
See ios/README-AR.md for signing, build and installation instructions.
